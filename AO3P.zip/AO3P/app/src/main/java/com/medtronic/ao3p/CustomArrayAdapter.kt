package com.medtronic.ao3p

import android.content.Context
import android.widget.ArrayAdapter

class CustomArrayAdapter<T>(context: Context?, simpleListItem1: T, toArray: T) {

}
